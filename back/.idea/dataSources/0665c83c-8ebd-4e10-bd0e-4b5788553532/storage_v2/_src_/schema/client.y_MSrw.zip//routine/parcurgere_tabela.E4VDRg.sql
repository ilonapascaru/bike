CREATE PROCEDURE parcurgere_tabela()
  BEGIN
declare done int default false;
declare bdate char(30);
declare count int;
declare qry1 char(60);
declare curs cursor for select baza_de_date from cod_client;
declare continue handler for not found set done=true;
open curs;
set count=0;
parcurgere :loop
fetch curs into bdate;
if done then 
leave parcurgere;
end if;
set @qry1=concat('select * from ',@bdate,'.licenta');
if(!strcmp(bdate,'learn')) then
prepare stmt from @qry1 ;
execute stmt ;
else 
set count=count+1;
end if;
end loop;
close curs;
select count from dual;

END;
