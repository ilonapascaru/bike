CREATE FUNCTION numerand(nr INT)
  RETURNS VARCHAR(50)
  begin
declare i int default nr ;

case i

when 1 then return 'Belgiu';

when 2 then return 'Aroneanu';

when 3 then return 'Sabadac';

when 4 then return 'Prisecaru';

when 5 then return 'Mironescu';

when 6 then return 'Rusu';

when 7 then return 'Ionescu';

when 8 then return 'Popescu';

when 9 then return 'Elisei';

when 10 then return 'Bogdanescu';
else return 'Bunicu';
end case;
end;
