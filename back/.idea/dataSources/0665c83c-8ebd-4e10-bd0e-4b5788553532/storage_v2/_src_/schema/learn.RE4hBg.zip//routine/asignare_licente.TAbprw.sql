CREATE PROCEDURE asignare_licente(IN id_ut BIGINT, IN nr_licente INT)
  begin
declare id bigint(20);
declare dat datetime;


set id=round(rand()*99999999999);
set dat=timestamp('2012-04-30 14:53:27')-interval rand()*365*2 day;

insert into licenta(id,id_utilizator,numar,data_creare) values (id,id_ut,nr_licente,dat);


end;
