CREATE FUNCTION prenume(nr INT)
  RETURNS VARCHAR(50)
  begin

if nr=1 then return 'Maria';
end if;

if nr=2 then return 'Mariana';
end if;

if nr=3 then return 'Ioana';
end if;

if nr=4 then return 'Marian';
end if;

if nr=5 then return 'Matei';
end if;

if nr=6 then return 'Bogdan';
end if;

if nr=7 then return 'Andrei';
end if;

if nr=8 then return 'Cristi';
end if;

if nr=9 then return 'Elena';
end if;

if nr=10 then return 'Ana';
end if;

if nr>10 then return 'Bunica';
end if;
end;
