CREATE PROCEDURE generare_rapoarte(IN id_util BIGINT, IN id_licenta BIGINT)
  begin
declare id bigint(20);
declare stat int(4);
declare patt varchar(50);
declare verificare int;
declare random int;

set random=round(rand()*5);
set id=round(rand()*9999999999);
select pattern(random) into patt;
set stat=round(rand()*5);
set verificare=round(rand()*100);

insert into raport(id, id_utilizator,id_licenta,statuss,pattern,verificare)
 values (id,id_util,id_licenta,stat,patt,verificare);

end;
