CREATE PROCEDURE asignare_licente_random()
  begin
declare random int;

declare id_client bigint;

declare done int default false;

declare c1 cursor for select id from utilizator;

declare continue handler for  not found set done=true;

open c1;

parcurgere:loop
fetch c1 into id_client;
if done then leave parcurgere;
end if;
set random=round(rand()*40);
 call asignare_licente(id_client,random);
end loop;

close c1;

end;
