CREATE PROCEDURE generare_rapoarte_random()
  begin
declare id_licen bigint;
declare id_util bigint;
declare numar_licente int;
declare i int;

declare done int default false;
declare c1 cursor for select id,id_utilizator, numar from licenta;
declare continue handler for  not found set done=true;

open c1;
parcurgere:loop
fetch c1 into id_licen,id_util,numar_licente;
if done then leave parcurgere;
end if;

set i=round(rand()*numar_licente);

 generare: loop
 call generare_rapoarte(id_util,id_licen);
 set i=i-1;
 if i=0 then leave generare;
 end if;
 end loop;
end loop;


end;
