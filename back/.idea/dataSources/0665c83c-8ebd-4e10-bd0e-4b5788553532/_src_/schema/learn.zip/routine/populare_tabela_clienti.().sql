CREATE PROCEDURE populare_tabela_clienti()
  begin		
declare id int;
declare nume varchar(50);
declare nume1 varchar(24);
declare pren varchar(20);
declare parola varchar(50);
declare email varchar(50);
declare numar_populari int default 0;

declare random1 int;
declare random2 int;

populare:loop
set id= round(rand()*999999999);

set random1=round(rand()*10);
set random2=round(rand()*10);

select numerand(random1) into nume1;
select prenume(random2) into pren;
select concat(nume1," ",pren) into nume;

select concat(nume1, (round(rand()*10)) ) into parola;

select concat(lower(nume1),".",lower(pren),"@yahoo.com") into email;

insert into utilizator(id,nume,parola,email) value (id,nume,parola,email);

set numar_populari=numar_populari+1;
if numar_populari=10 then leave populare;
end if;
end loop populare;

end;
