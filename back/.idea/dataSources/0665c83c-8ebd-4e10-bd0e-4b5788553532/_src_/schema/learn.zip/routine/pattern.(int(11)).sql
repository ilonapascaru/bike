CREATE FUNCTION pattern(i INT)
  RETURNS VARCHAR(40)
  begin

case i

when 1 then return 'Gutman';

when 2 then return 'Baseline';

else return 'Standard';
 
end case;

end;
