CREATE PROCEDURE populare_tabela()
  begin
    declare id bigint(20);
    declare cc int(6);
    declare  baza_de_date varchar(40);
    declare r1 int;
    declare r2 int;

    set r1=round(rand()*10);
    set r2=round(rand()*10);

    set id=round(rand()*99999);
    set cc=round(rand()*999999);
    select concat("utilizator_",cc) into baza_de_date;

    insert into cod_client(id,cc,baza_de_date) values (id,cc,baza_de_date);


  end;
